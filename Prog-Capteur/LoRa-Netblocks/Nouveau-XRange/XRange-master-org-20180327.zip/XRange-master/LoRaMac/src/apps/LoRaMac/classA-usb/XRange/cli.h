#ifndef __CLI_H__
#define __CLI_H__
#include <stdint.h>
#include "cmdline.h"

void cli_process(void);
void cli_init(void);

#endif
