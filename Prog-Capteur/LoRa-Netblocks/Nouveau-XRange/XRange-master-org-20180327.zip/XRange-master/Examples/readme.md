----------------------------------------------------------------
www.netblocks.eu
XRange sx1272 LoRa RF module
Data sheet at www.netblocks.eu/xrange-sx1272-lora-datasheet/
----------------------------------------------------------------

Examples description:

docs/ping-pong.txt
docs/USB-RF.txt
