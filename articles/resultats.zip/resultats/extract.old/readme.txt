First number : Number of IN max PER GW
Seconde number : Number of GW max PER WELL