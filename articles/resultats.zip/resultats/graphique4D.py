from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')


#POUR 1 MSG PAR JOUR en  agrege
#x =msg IN
#y=numero simulation
#z=degre IN
#c=degre GW

donnée_msg_in=[] #x1
donnée_msg_gw=[] #x2
donnée_msg_well=[] #x4
donnée_bat_in=[] #x3
donnée_bat_gw=[] #x4

degree_in=[] #y
degree_gw=[] #z
numero_simulation[] #c



max_degree_IN= 4
max_degree_GW= 4
nb_vertex= 1000
nb_graph=100
current_degree_IN=4
current_degree_GW=4

#try 4D
simu_msg_evaluate="1"
while current_degree_IN < max_degree_IN+1:
	while current_degree_GW < max_degree_GW+1:
		filename=str(current_degree_IN)+"-"+str(current_degree_GW)
		dirs = os.listdir( "extract/"+filename1+"/"+simu_msg_evaluate)
		print(filename1)
		i=0
		for file in dirs:
			with open(file) as f :
				donnée_msg_in.append(float(f.readline())
				donnée_msg_gw.append(float(f.readline())
				donnée_msg_well.append(float(f.readline())
				donnée_bat_in.append(float(f.readline())
				donnée_bat_gw.append(float(f.readline())
				degree_in.append(current_degree_IN)
				degree_gw.append(current_degree_GW)
				numero_simulation.append(i)
				f.close()
			i=i+1







#x = np.random.standard_normal(100) #donnée msg in 
#y = np.random.standard_normal(100)
#z = np.random.standard_normal(100)
#c = np.random.standard_normal(100)
ax.scatter(donnée_msg_in, degree_in, degree_gw, c=numero_simulation, cmap=plt.hot())
plt.show()


ax.scatter(x, y, z, c=c, cmap=plt.hot())
plt.show()