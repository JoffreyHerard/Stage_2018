var struct_core_debug___type =
[
    [ "DCRDR", "struct_core_debug___type.html#aab3cc92ef07bc1f04b3a3aa6db2c2d55", null ],
    [ "DCRSR", "struct_core_debug___type.html#af907cf64577eaf927dac6787df6dd98b", null ],
    [ "DEMCR", "struct_core_debug___type.html#aeb3126abc4c258a858f21f356c0df6ee", null ],
    [ "DHCSR", "struct_core_debug___type.html#ad63554e4650da91a8e79929cbb63db66", null ]
];