var searchData=
[
  ['startup_20file_20startup_5f_3cdevice_3e_2es',['Startup File startup_&lt;device&gt;.s',['../startup_s_pg.html',1,'Templates_pg']]],
  ['system_20configuration_20files_20system_5f_3cdevice_3e_2ec_20and_20system_5f_3cdevice_3e_2eh',['System Configuration Files system_&lt;device&gt;.c and system_&lt;device&gt;.h',['../system_c_pg.html',1,'Templates_pg']]]
];
