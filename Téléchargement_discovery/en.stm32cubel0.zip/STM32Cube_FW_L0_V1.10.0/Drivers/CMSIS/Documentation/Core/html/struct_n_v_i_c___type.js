var struct_n_v_i_c___type =
[
    [ "IABR", "struct_n_v_i_c___type.html#a4bca5452748ba84d64536fb6a5d795af", null ],
    [ "ICER", "struct_n_v_i_c___type.html#a245df8bac1da05c39eadabede9323203", null ],
    [ "ICPR", "struct_n_v_i_c___type.html#a8d8f45d9c5c67bba3c153c55574bac95", null ],
    [ "IP", "struct_n_v_i_c___type.html#a7ff7364a4260df67a2784811e8da4efd", null ],
    [ "ISER", "struct_n_v_i_c___type.html#a9fccef5a60a0d5e81fcd7869a6274f47", null ],
    [ "ISPR", "struct_n_v_i_c___type.html#a8f731a9f428efc86e8d311b52ce823d0", null ],
    [ "RESERVED0", "struct_n_v_i_c___type.html#a2de17698945ea49abd58a2d45bdc9c80", null ],
    [ "RESERVED2", "struct_n_v_i_c___type.html#a0953af43af8ec7fd5869a1d826ce5b72", null ],
    [ "RESERVED3", "struct_n_v_i_c___type.html#a9dd330835dbf21471e7b5be8692d77ab", null ],
    [ "RESERVED4", "struct_n_v_i_c___type.html#a5c0e5d507ac3c1bd5cdaaf9bbd177790", null ],
    [ "RESERVED5", "struct_n_v_i_c___type.html#a4f753b4f824270175af045ac99bc12e8", null ],
    [ "RSERVED1", "struct_n_v_i_c___type.html#a6d1daf7ab6f2ba83f57ff67ae6f571fe", null ],
    [ "STIR", "struct_n_v_i_c___type.html#a37de89637466e007171c6b135299bc75", null ]
];